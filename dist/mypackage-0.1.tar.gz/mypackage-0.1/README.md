# mypackage
This library was created as an example of how to publish your Python package

## Building this package locally
`python setup.py sdist`

## Installing this package from GitHub
`pip install git+https://github.com/wn-zarathustra/mypackage.git`

## Updating this package from GitHub
`pip install --update git+https://github.com/wn-zarathustra/mypackage.git`